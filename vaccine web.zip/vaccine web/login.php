<link rel="stylesheet" href="style_login.css">
<form action="login-check.php" method="POST">
<center>
<h1>Login here </h1>
</center>
<label>Email:</label>
  <input type="email" name="email" required>

  <label>Password:</label>
  <input type="password" name="password" required>

  <br>
  <button type="submit" class="button">Log in</button>

  <div class="social">
          <div class="lb"><a href="signup.php">Sign Up</div></a>
       <div class="rb"><a href="admin.php">Log In as admin </div></a>

    
        </div>
        <br>
        <div><a href="index.php">← BACK</div></a>
</form>

