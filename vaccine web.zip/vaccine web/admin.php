<?php
session_start(); // Start a new session

if ($_SERVER['REQUEST_METHOD'] == 'POST') { // If form is submitted
    $username = $_POST['admin_name'];
    $password = $_POST['admin_password'];
    
    // Connect to MySQL database
    $conn = mysqli_connect('localhost', 'root', '', 'user_db');
    
    // Query the users table for a matching username and password
    $result = mysqli_query($conn, "SELECT * FROM admin_login WHERE admin_name='$username' AND admin_password='$password'");
    
    if (mysqli_num_rows($result) == 1) { // If match found
        $_SESSION['admin_name'] = $username; // Set session variable
        header('Location: admin_dashboard.php'); // Redirect to admin page
    } else {
        $error = "Invalid username or password"; // Set error message
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VaccineWay</title>
    <link rel="stylesheet" href="style_login.css">
    <style>
             * {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
}

.banner {
    width: 100%;
    height: 100vh;
    background: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(img/carousel-2.jpg);
    background-size: cover;
    background-position: center;
    position: relative;
}

.navbar {
    width: 85%;
    margin: auto;
    padding: 35px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.navbar img{
    border-radius:100px;
    width: 80px;
}
.logo {
    width: 80px;
    cursor: pointer;
}

.navbar ul {
    list-style: none;
    display: flex;
    align-items: center;
}

.navbar ul li {
    list-style: none;
    display: inline-block;
    margin: 0 20px;
    position: relative;
}

.navbar ul li a {
    text-decoration: none;
    color: #fff;
    text-transform: uppercase;
}

.navbar ul li::after {
    content: '';
    height: 3px;
    width: 0;
    background: #009688;
    position: absolute;
    left: 0;
    bottom: -10px;
    transition: 0.5s;
}

.navbar ul li:hover::after {
    width: 100%;
}

.content {
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    text-align: center;
    color: #fff;
}

.content h1 {
    font-size: 70px;
    margin-top: 80px;
}
.img-fluid {
    max-width: 100%;
    height: auto;
}
img, svg {
    vertical-align: middle;
}
.content p {
    margin: 20px auto;
    font-weight: 100;
    line-height: 25px;
}
.button1 {
    width: 100px;
    padding: 15px 0;
    text-align: center;
    /* margin: 20px 10px; */
    border-radius: 25px;
    font-weight: bold;
    border: 2px solid #009688;
    background: transparent;
    color: #fff;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.button1 span {
    background: #009688;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;
}

.button1:hover span {
    width: 100%;
}

.button1:hover {
    border: none;
}
.button {
    width: 200px;
    padding: 15px 0;
    text-align: center;
    margin: 20px 10px;
    border-radius: 25px;
    font-weight: bold;
    border: 2px solid #009688;
    background: transparent;
    color: #fff;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.button span {
    background: #009688;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;
}

.button:hover span {
    width: 100%;
}

.button:hover {
    border: none;
}

@media (max-width: 768px) {
    .navbar ul {
        flex-direction: column;
        align-items: center;
    }

    .navbar ul li {
        margin: 10px 0;
    }

    .content h1 {
        font-size: 50px;
    }

    .content p {
        font-size: 16px;
    }

    .button {
        width: 150px;
        padding: 10px 0;
        margin: 10px 5px;
    }
}

@media (max-width: 480px) {
    .navbar {
        flex-direction: column;
    }

    .content h1 {
        font-size: 40px;
    }

    .content p {
        font-size: 14px;
    }

    .button {
        width: 120px;
        padding: 8px 0;
        margin: 8px 4px;
    }
}
    </style>
</head>
<body>
<div class="banner">
        <div class="navbar">
            <img src="img/logo-1.jpeg" alt="Logo" class="logo animated slideInLeft">
            <ul class="animated slideInDown">
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Hospital</a></li>
                <li><a href="#">Service</a></li>
                <button type="button" class="button1 animated slideInDown">login<span></span></button>
             
            </ul>
        </div>
</div>
<div class="background">
        
        </div>
        <form action="" method="post">
            <h3>Admin Login</h3>
    
            <label class="adminlabel">Admin Name: </label>
            <input type="text" placeholder="Email or Phone" name="admin_name">
    
            <label class="adminlabel">Admin Password: </label>
            <input type="password" placeholder="Password"  name="admin_password">
    
            <br>
            <br>
            <input type="submit" name="login" value="login" class="button">
            <div class="social">
              <div class="lb"><a href="signup.php">Sign Up</div></a>
           <div class="rb"><a href="login.php">Log In as user </div></a>
            </div>
        </form>
</body>
</html>