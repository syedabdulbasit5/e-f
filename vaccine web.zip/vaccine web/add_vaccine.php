<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>VaccineWay</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/twentytwenty/twentytwenty.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<style>
           * {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
}

.banner {
    width: 100%;
    height: 100vh;
    background: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(img/carousel-2.jpg);
    background-size: cover;
    background-position: center;
    position: relative;
}

.navbar {
    width: 85%;
    margin: auto;
    padding: 35px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.navbar img{
    border-radius:100px;
    width: 80px;
}
.logo {
    width: 80px;
    cursor: pointer;
}

.navbar ul {
    list-style: none;
    display: flex;
    align-items: center;
}

.navbar ul li {
    list-style: none;
    display: inline-block;
    margin: 0 20px;
    position: relative;
}

.navbar ul li a {
    text-decoration: none;
    color: #fff;
    text-transform: uppercase;
}

.navbar ul li::after {
    content: '';
    height: 3px;
    width: 0;
    background: #009688;
    position: absolute;
    left: 0;
    bottom: -10px;
    transition: 0.5s;
}

.navbar ul li:hover::after {
    width: 100%;
}

.content {
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    text-align: center;
    color: #fff;
}

.content h1 {
    font-size: 70px;
    margin-top: 80px;
}
.img-fluid {
    max-width: 100%;
    height: auto;
}
img, svg {
    vertical-align: middle;
}
.content p {
    margin: 20px auto;
    font-weight: 100;
    line-height: 25px;
}
.button1 {
    width: 100px;
    padding: 15px 0;
    text-align: center;
    /* margin: 20px 10px; */
    border-radius: 25px;
    font-weight: bold;
    border: 2px solid #009688;
    background: transparent;
    color: #fff;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.button1 span {
    background: #009688;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;
}

.button1:hover span {
    width: 100%;
}

.button1:hover {
    border: none;
}
.button {
    width: 200px;
    padding: 15px 0;
    text-align: center;
    margin: 20px 10px;
    border-radius: 25px;
    font-weight: bold;
    border: 2px solid #009688;
    background: transparent;
    color: #fff;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.button span {
    background: #009688;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;
}

.button:hover span {
    width: 100%;
}

.button:hover {
    border: none;
}

@media (max-width: 768px) {
    .navbar ul {
        flex-direction: column;
        align-items: center;
    }

    .navbar ul li {
        margin: 10px 0;
    }

    .content h1 {
        font-size: 50px;
    }

    .content p {
        font-size: 16px;
    }

    .button {
        width: 150px;
        padding: 10px 0;
        margin: 10px 5px;
    }
}

@media (max-width: 480px) {
    .navbar {
        flex-direction: column;
    }

    .content h1 {
        font-size: 40px;
    }

    .content p {
        font-size: 14px;
    }

    .button {
        width: 120px;
        padding: 8px 0;
        margin: 8px 4px;
    }
}

</style>
<body>

    <!-- Navbar Start -->
    <!-- <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm px-5 py-3 py-lg-0">
        <a href="index.php" class="navbar-brand p-0">
            <img src="img/logo.jpg" class="img-fluid" alt="" style="width: 230px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
            </div>
            <a href="index.php" class="btn btn-primary py-2 px-4 ms-3">Log out</a>
        </div>
    </nav> -->
    <!-- Navbar End -->

    <div class="container mt-5">
        <h2>Add New Vaccine</h2>
        <form action="add_vaccine.php" method="post">
            <div class="form-group">
                <label for="vaccine_name">Vaccine Name:</label>
                <input type="text" class="form-control" id="vaccine_name" name="vaccine_name" required>
            </div>
            <div class="form-group">
                <label for="availability">Availability:</label>
                <input type="text" class="form-control" id="availability" name="availability" required>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Add New Vaccine</button>
        </form>

        <?php
        // Create a new connection to the database
        $conn = mysqli_connect("localhost", "root", "", "user_db");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Process the form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $vaccine_name = $_POST["vaccine_name"];
            $availability = $_POST["availability"];

            $sql = "INSERT INTO vaclist (Vaccine_name, Availability) VALUES ('$vaccine_name', '$availability')";
            if (mysqli_query($conn, $sql)) {
                echo "<div class='alert alert-success mt-3'>New vaccine added successfully</div>";
            } else {
                echo "<div class='alert alert-danger mt-3'>Error: " . $sql . "<br>" . mysqli_error($conn) . "</div>";
            }
        }

        mysqli_close($conn);
        ?>
    </div>
</body>
</html>
